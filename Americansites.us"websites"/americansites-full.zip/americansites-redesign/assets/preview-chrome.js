(() => {
  const body = document.body;
  document.documentElement.classList.add('as-concept-page');

  if (window.self !== window.top) {
    document.documentElement.classList.add('as-framed');
    const badge = document.createElement('span');
    badge.className = 'as-frame-badge';
    badge.textContent = 'Website concept';
    badge.setAttribute('aria-hidden', 'true');
    body.append(badge);
    return;
  }

  const rawTitle = document.title.split('|')[0].split('•')[0].trim();
  const designName = rawTitle
    .replace(/\s+Template$/i, '')
    .replace(/\s+Website (Example|Concept)$/i, '')
    .trim();
  const queryDesign = encodeURIComponent(designName || 'Website Concept');

  document.querySelectorAll('body > header.sticky, body > nav.sticky, body > .sticky.top-0').forEach((element) => {
    element.classList.add('as-site-nav');
  });

  const bar = document.createElement('aside');
  bar.className = 'as-preview';
  bar.setAttribute('aria-label', 'AmericanSites website preview controls');
  bar.innerHTML = `
    <div class="as-preview__inner">
      <div class="as-preview__brand">
        <img src="assets/americansites-logo.png" alt="" width="34" height="34">
        <div class="as-preview__brand-copy">
          <b>AmericanSites Design Concept</b>
          <span>${designName} — professionally designed and fully customizable</span>
        </div>
      </div>
      <div class="as-preview__actions">
        <a href="index.html#work" aria-label="Back to all website concepts">← <span>All Concepts</span></a>
        <a href="index.html?design=${queryDesign}#contact" aria-label="Build a customized version of ${designName}"><span>Build My Version</span> ↗</a>
      </div>
    </div>`;
  body.prepend(bar);

  const disclaimer = document.createElement('aside');
  disclaimer.className = 'as-demo-disclaimer';
  disclaimer.innerHTML = `
    <div class="as-demo-disclaimer__inner">
      <i aria-hidden="true">i</i>
      <p><strong>Professional website concept.</strong> Business names, reviews, pricing, addresses, statistics, and contact details shown here are sample content. Your version will be rebuilt around your real brand, services, proof, and customer goals.</p>
    </div>`;
  const footer = body.querySelector('footer');
  if (footer) footer.before(disclaimer);
  else body.append(disclaimer);
})();
