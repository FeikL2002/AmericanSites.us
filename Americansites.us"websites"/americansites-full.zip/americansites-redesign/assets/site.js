(() => {
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const entryGate = document.getElementById('entry-gate');
  const enterSiteButton = document.getElementById('enter-site');
  const pageContent = [...document.body.children].filter((element) => element !== entryGate && element.tagName !== 'SCRIPT');
  const header = document.querySelector('.site-header');
  const navToggle = document.querySelector('.nav-toggle');
  const nav = document.querySelector('.nav-links');

  pageContent.forEach((element) => { element.inert = true; });
  window.scrollTo(0, 0);
  window.setTimeout(() => enterSiteButton?.focus(), reducedMotion ? 0 : 1200);

  enterSiteButton?.addEventListener('click', () => {
    entryGate.classList.add('is-leaving');
    document.body.classList.remove('entry-locked');
    pageContent.forEach((element) => { element.inert = false; });
    if (window.location.hash) history.replaceState(null, '', `${window.location.pathname}${window.location.search}`);
    window.scrollTo(0, 0);
    window.setTimeout(() => {
      entryGate.hidden = true;
      document.getElementById('main')?.focus({ preventScroll: true });
    }, reducedMotion ? 0 : 620);
  });

  document.getElementById('year').textContent = new Date().getFullYear();

  const updateHeader = () => header?.classList.toggle('is-scrolled', window.scrollY > 24);
  updateHeader();
  window.addEventListener('scroll', updateHeader, { passive: true });

  navToggle?.addEventListener('click', () => {
    const open = nav.classList.toggle('is-open');
    navToggle.setAttribute('aria-expanded', String(open));
  });

  nav?.querySelectorAll('a').forEach((link) => {
    link.addEventListener('click', () => {
      nav.classList.remove('is-open');
      navToggle?.setAttribute('aria-expanded', 'false');
    });
  });

  const reveals = document.querySelectorAll('.reveal');
  if (reducedMotion || !('IntersectionObserver' in window)) {
    reveals.forEach((item) => item.classList.add('is-visible'));
  } else {
    const revealObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      });
    }, { threshold: 0.08, rootMargin: '0px 0px -35px' });
    reveals.forEach((item) => revealObserver.observe(item));
  }

  const sections = [...document.querySelectorAll('main section[id]')];
  const navLinks = [...document.querySelectorAll('.nav-links a')];
  if ('IntersectionObserver' in window) {
    const sectionObserver = new IntersectionObserver((entries) => {
      const visible = entries.filter((entry) => entry.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
      if (!visible) return;
      navLinks.forEach((link) => link.classList.toggle('is-active', link.getAttribute('href') === `#${visible.target.id}`));
    }, { rootMargin: '-32% 0px -55%', threshold: [0, .2, .5] });
    sections.forEach((section) => sectionObserver.observe(section));
  }

  const process = document.querySelector('.process-track');
  const processProgress = document.getElementById('process-progress');
  const processSteps = [...document.querySelectorAll('.process-track article')];
  const updateProcess = () => {
    if (!process || !processProgress) return;
    const rect = process.getBoundingClientRect();
    const start = window.innerHeight * .68;
    const progress = Math.max(0, Math.min(1, (start - rect.top) / Math.max(rect.height * .72, 1)));
    processProgress.style.width = `${progress * 100}%`;
    processSteps.forEach((step, index) => step.classList.toggle('is-reached', progress >= index / Math.max(processSteps.length - 1, 1) - .03));
  };
  updateProcess();
  window.addEventListener('scroll', updateProcess, { passive: true });
  window.addEventListener('resize', updateProcess);

  if (!reducedMotion && window.matchMedia('(pointer: fine)').matches) {
    document.querySelectorAll('[data-tilt]').forEach((card) => {
      card.addEventListener('pointermove', (event) => {
        const rect = card.getBoundingClientRect();
        const x = (event.clientX - rect.left) / rect.width - .5;
        const y = (event.clientY - rect.top) / rect.height - .5;
        card.style.setProperty('--mx', `${x * 1.4}deg`);
        card.style.setProperty('--my', `${y * -1.2}deg`);
      });
      card.addEventListener('pointerleave', () => {
        card.style.setProperty('--mx', '0deg');
        card.style.setProperty('--my', '0deg');
      });
    });
  }

  document.querySelectorAll('.faq-list details').forEach((detail) => {
    detail.addEventListener('toggle', () => {
      if (!detail.open) return;
      document.querySelectorAll('.faq-list details').forEach((other) => {
        if (other !== detail) other.open = false;
      });
    });
  });

  const form = document.getElementById('project-form');
  const formSteps = [...document.querySelectorAll('.form-step')];
  const nextButton = document.querySelector('.form-next');
  const backButton = document.querySelector('.form-back');
  const submitButton = document.querySelector('.form-submit');
  const stepLabel = document.getElementById('step-label');
  const progressBar = document.getElementById('form-progress');
  const review = document.getElementById('form-review');
  let currentStep = 0;

  const fieldValue = (name) => {
    const field = form?.elements.namedItem(name);
    return field && 'value' in field ? field.value.trim() : '';
  };

  const addReviewItem = (label, value) => {
    const item = document.createElement('div');
    const caption = document.createElement('span');
    const answer = document.createElement('b');
    caption.textContent = label;
    answer.textContent = value || 'Not provided';
    item.append(caption, answer);
    review.append(item);
  };

  const buildReview = () => {
    if (!review) return;
    review.replaceChildren();
    addReviewItem('Name', fieldValue('name'));
    addReviewItem('Business', fieldValue('business'));
    addReviewItem('Industry', fieldValue('industry'));
    addReviewItem('Primary goal', fieldValue('primary_goal'));
    addReviewItem('Design direction', fieldValue('template_interest'));
    addReviewItem('Contact', fieldValue('email'));
  };

  const updateFormStep = () => {
    formSteps.forEach((step, index) => step.classList.toggle('is-active', index === currentStep));
    stepLabel.textContent = `Step ${currentStep + 1} of ${formSteps.length}`;
    progressBar.style.width = `${((currentStep + 1) / formSteps.length) * 100}%`;
    backButton.hidden = currentStep === 0;
    nextButton.hidden = currentStep === formSteps.length - 1;
    submitButton.hidden = currentStep !== formSteps.length - 1;
    if (currentStep === formSteps.length - 1) buildReview();
  };

  const validateStep = () => {
    const fields = [...formSteps[currentStep].querySelectorAll('input, select, textarea')];
    for (const field of fields) {
      if (!field.checkValidity()) {
        field.reportValidity();
        field.focus();
        return false;
      }
    }
    return true;
  };

  nextButton?.addEventListener('click', () => {
    if (!validateStep()) return;
    currentStep = Math.min(currentStep + 1, formSteps.length - 1);
    updateFormStep();
  });
  backButton?.addEventListener('click', () => {
    currentStep = Math.max(currentStep - 1, 0);
    updateFormStep();
  });
  form?.addEventListener('keydown', (event) => {
    if (event.key !== 'Enter' || event.target.matches('textarea') || currentStep === formSteps.length - 1) return;
    event.preventDefault();
    nextButton.click();
  });
  form?.addEventListener('submit', () => {
    document.getElementById('reply-to').value = document.getElementById('project-email').value;
    submitButton.textContent = 'Sending your request…';
  });

  const requestedDesign = new URLSearchParams(window.location.search).get('design');
  const designSelect = document.getElementById('design-select');
  if (requestedDesign && designSelect) {
    const match = [...designSelect.options].find((option) => option.textContent.toLowerCase() === requestedDesign.toLowerCase());
    if (match) designSelect.value = match.value;
  }
  updateFormStep();

  document.querySelectorAll('[data-dialog]').forEach((button) => {
    button.addEventListener('click', () => document.getElementById(`${button.dataset.dialog}-dialog`)?.showModal());
  });
  document.querySelectorAll('.legal-dialog').forEach((dialog) => {
    dialog.querySelector('.dialog-close')?.addEventListener('click', () => dialog.close());
    dialog.addEventListener('click', (event) => {
      if (event.target === dialog) dialog.close();
    });
  });
})();
