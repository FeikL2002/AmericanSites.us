import { cp, mkdir, readdir, readFile, rm, writeFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const dist = resolve(root, 'dist');
const client = resolve(dist, 'client');
const server = resolve(dist, 'server');
const hosting = resolve(dist, '.openai');

await rm(dist, { recursive: true, force: true });
await mkdir(client, { recursive: true });
await mkdir(server, { recursive: true });
await mkdir(hosting, { recursive: true });

for (const entry of await readdir(root, { withFileTypes: true })) {
  if (entry.isFile() && entry.name.endsWith('.html')) {
    await cp(resolve(root, entry.name), resolve(client, entry.name));
  }
}

await cp(resolve(root, 'assets'), resolve(client, 'assets'), { recursive: true });
await cp(resolve(root, 'worker/index.js'), resolve(server, 'index.js'));
await cp(resolve(root, '.openai/hosting.json'), resolve(hosting, 'hosting.json'));

const homepage = await readFile(resolve(client, 'index.html'), 'utf8');
const requiredCopy = [
  'Websites Built to Make Your Business',
  'More Than a Website',
  'Industry website concepts',
  'Professional by',
  '2 of Our Live Websites',
  '330 Lab Wrestling Club',
  'labelitephotography.com',
  'Northline Auto Co.',
  'americansites-share.png',
  'A Simple Process',
  'Let’s Build Something Your Business Can Be',
];
for (const phrase of requiredCopy) {
  if (!homepage.includes(phrase)) throw new Error(`Missing required homepage content: ${phrase}`);
}

const demos = (await readdir(client)).filter((name) => name.endsWith('.html') && name !== 'index.html');
for (const demo of demos) {
  const html = await readFile(resolve(client, demo), 'utf8');
  if (!html.includes('preview-chrome.js')) throw new Error(`Preview chrome missing from ${demo}`);
  if (!html.includes('noindex,nofollow')) throw new Error(`Search protection missing from concept page ${demo}`);
  if (html.includes('index.html#templates')) throw new Error(`Legacy preview bar remains in ${demo}`);
}

const automotive = await readFile(resolve(client, 'car-sales.html'), 'utf8');
if (/lewis/i.test(automotive)) throw new Error('Owner-specific name remains in automotive concept');

const fitnessPosition = homepage.indexOf('IronWill Performance');
const lawnPosition = homepage.indexOf('ProCuts Landscaping');
if (fitnessPosition < 0 || lawnPosition < 0 || fitnessPosition > lawnPosition) {
  throw new Error('Fitness concept must remain the first featured website concept');
}

await writeFile(resolve(dist, 'build-summary.json'), JSON.stringify({ pages: demos.length + 1, demos: demos.length }, null, 2));
console.log(`Built ${demos.length + 1} pages (${demos.length} website previews).`);
