# AmericanSites.us Redesign

Premium dark redesign of AmericanSites.us with:

- Responsive desktop and mobile layouts
- Nine complete website example pages
- Multi-step website request form
- Premium preview bars and demonstration disclaimers
- Refined animation, hover, navigation, and FAQ interactions
- Reproducible static build and Sites deployment configuration

Open `index.html` to view the static website directly.

To create the production-ready `dist` folder:

```sh
npm run build
```

The build uses Node.js only and does not require package installation.
