(function () {
  "use strict";

  var shopForm = document.querySelector('form[action*="formsubmit.co"]');
  var itemNames = [
    "shirt_selected",
    "khaki_hat_selected",
    "black_hat_selected",
    "gray_hat_selected",
  ];
  var itemInputs = itemNames
    .map(function (name) {
      return document.querySelector('input[name="' + name + '"]');
    })
    .filter(Boolean);

  var styles = document.createElement("style");
  styles.textContent =
    ".static-lightbox{position:fixed;inset:0;z-index:2000;background:rgba(3,10,6,.9);display:grid;place-items:center;padding:24px;backdrop-filter:blur(8px)}" +
    "button[aria-label^=\"View larger image\"]{touch-action:manipulation;-webkit-tap-highlight-color:transparent}" +
    ".static-lightbox-card{width:min(900px,100%);max-height:calc(100vh - 48px);background:#fff;color:#111;position:relative;display:grid;grid-template-columns:minmax(0,1.35fr) minmax(250px,.65fr);overflow:auto}" +
    ".static-lightbox-media{display:flex;align-items:center;background:#f4f2ec;min-width:0;touch-action:pan-y;user-select:none}" +
    ".static-lightbox-media img{-webkit-user-drag:none}" +
    ".static-lightbox-media>div{width:100%}" +
    ".static-lightbox-copy{padding:42px 30px;display:flex;flex-direction:column;justify-content:flex-end}" +
    ".static-lightbox-copy span{font:800 10px/1.4 Arial,sans-serif;text-transform:uppercase;letter-spacing:.12em;color:#69736c}" +
    ".static-lightbox-copy h2{font:700 44px/1 Impact,Arial,sans-serif;text-transform:uppercase;margin:12px 0 30px}" +
    ".static-lightbox-copy button{border:1px solid #173a27;background:transparent;padding:13px;text-transform:uppercase;font-size:10px;font-weight:800;cursor:pointer}" +
    ".static-lightbox-nav{display:grid;grid-template-columns:1fr 1fr;gap:8px}" +
    ".static-lightbox-add{margin-top:10px;background:#d7ff3f!important;border-color:#d7ff3f!important;color:#0b2418}" +
    ".static-lightbox-close{position:absolute;z-index:3;right:14px;top:14px;width:42px;height:42px;border-radius:50%;border:0;background:#d7ff3f;color:#0b2418;font-size:28px;line-height:1;cursor:pointer}" +
    ".static-choice-selected{background:#f1f8d9!important;border-color:#6f8b25!important;box-shadow:inset 0 0 0 1px #6f8b25}" +
    ".static-dynamic-fields{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:22px}" +
    ".static-selected-item{border-left:4px solid #d7ff3f;background:#f4f6ef;padding:17px}" +
    ".static-selected-item h3{margin:0 0 14px;font:400 22px/1 Impact,Arial,sans-serif;text-transform:uppercase}" +
    ".static-selected-item label{margin:0!important}" +
    ".static-shirt-fields{display:grid;grid-template-columns:1.25fr .75fr;gap:18px}" +
    ".static-form-error{background:#ffe1dc;color:#8b2418;padding:12px;font-size:12px;font-weight:700;margin-bottom:18px}" +
    "@media(max-width:850px){.static-lightbox-card{grid-template-columns:1fr}.static-lightbox-copy{padding:24px}.static-lightbox-copy h2{font-size:38px;margin-bottom:18px}}" +
    "@media(max-width:520px){.static-lightbox{padding:10px}.static-lightbox-card{max-height:calc(100vh - 20px)}.static-lightbox-close{right:8px;top:8px}.static-lightbox-copy button{min-height:48px;touch-action:manipulation}.static-lightbox-nav,.static-dynamic-fields,.static-shirt-fields{grid-template-columns:1fr}}";
  document.head.appendChild(styles);

  function closeLightbox() {
    var current = document.querySelector(".static-lightbox");
    if (current) current.remove();
    document.body.style.overflow = "";
  }

  var productButtons = Array.from(document.querySelectorAll('button[aria-label^="View larger image of "]'));

  function openLightbox(index) {
      closeLightbox();
      var button = productButtons[index];
      var crop = button && button.querySelector("div");
      var figure = button && button.closest("figure");
      if (!button || !crop || !figure) return;

      var caption = figure.querySelector("figcaption");
      var category = caption && caption.querySelector("span") ? caption.querySelector("span").textContent : "Merch";
      var name = caption && caption.querySelector("strong") ? caption.querySelector("strong").textContent : button.getAttribute("aria-label").replace("View larger image of ", "");
      var overlay = document.createElement("div");
      overlay.className = "static-lightbox";
      overlay.setAttribute("role", "dialog");
      overlay.setAttribute("aria-modal", "true");
      overlay.setAttribute("aria-label", name + " enlarged view");
      overlay.innerHTML =
        '<div class="static-lightbox-card">' +
        '<button class="static-lightbox-close" type="button" aria-label="Close enlarged view">&times;</button>' +
        '<div class="static-lightbox-media"></div>' +
        '<div class="static-lightbox-copy"><span></span><h2></h2><div class="static-lightbox-nav"><button class="static-lightbox-prev" type="button">&larr; Previous</button><button class="static-lightbox-next" type="button">Next &rarr;</button></div><button class="static-lightbox-add" type="button">Add this item to request &darr;</button></div>' +
        "</div>";
      overlay.querySelector(".static-lightbox-media").appendChild(crop.cloneNode(true));
      overlay.querySelector(".static-lightbox-copy span").textContent = category + " · " + (index + 1) + " of " + productButtons.length;
      overlay.querySelector(".static-lightbox-copy h2").textContent = name;
      overlay.querySelectorAll(".static-lightbox-close").forEach(function (closeButton) {
        closeButton.addEventListener("click", closeLightbox);
      });
      overlay.querySelector(".static-lightbox-prev").addEventListener("click", function () {
        openLightbox((index - 1 + productButtons.length) % productButtons.length);
      });
      overlay.querySelector(".static-lightbox-next").addEventListener("click", function () {
        openLightbox((index + 1) % productButtons.length);
      });
      var touchStart = null;
      var media = overlay.querySelector(".static-lightbox-media");
      media.addEventListener("touchstart", function (event) {
        touchStart = event.touches[0] ? event.touches[0].clientX : null;
      }, { passive: true });
      media.addEventListener("touchend", function (event) {
        var end = event.changedTouches[0] ? event.changedTouches[0].clientX : null;
        if (touchStart === null || end === null || Math.abs(end - touchStart) < 50) return;
        openLightbox((index + (end > touchStart ? -1 : 1) + productButtons.length) % productButtons.length);
      }, { passive: true });
      overlay.querySelector(".static-lightbox-add").addEventListener("click", function () {
        var fieldName = index < 2 ? "shirt_selected" : ["khaki_hat_selected", "black_hat_selected", "gray_hat_selected"][index - 2];
        var input = document.querySelector('input[name="' + fieldName + '"]');
        if (input) {
          input.checked = true;
          input.dispatchEvent(new Event("change", { bubbles: true }));
        }
        closeLightbox();
        var order = document.getElementById("merch-order") || shopForm;
        if (order) order.scrollIntoView({ behavior: "smooth", block: "start" });
      });
      overlay.addEventListener("click", function (event) {
        if (event.target === overlay) closeLightbox();
      });
      document.body.appendChild(overlay);
      document.body.style.overflow = "hidden";
      overlay.querySelector(".static-lightbox-close").focus();
  }

  productButtons.forEach(function (button, index) {
    button.addEventListener("click", function () {
      openLightbox(index);
    });
  });

  document.addEventListener("keydown", function (event) {
    if (event.key === "Escape") closeLightbox();
  });

  if (!shopForm || !itemInputs.length) return;

  var picker = itemInputs[0].closest("fieldset");
  var dynamicFields = document.createElement("div");
  dynamicFields.className = "static-dynamic-fields";
  var formError = document.createElement("p");
  formError.className = "static-form-error";
  formError.hidden = true;
  picker.insertAdjacentElement("afterend", dynamicFields);
  dynamicFields.insertAdjacentElement("afterend", formError);

  function quantityBlock(title, inputName) {
    return (
      '<section class="static-selected-item">' +
      "<h3>" + title + "</h3>" +
      '<label>Quantity<input type="number" name="' + inputName + '" min="1" value="1" required></label>' +
      "</section>"
    );
  }

  function renderSelections() {
    itemInputs.forEach(function (input) {
      var label = input.closest("label");
      if (label) label.classList.toggle("static-choice-selected", input.checked);
    });

    var html = "";
    var shirt = document.querySelector('input[name="shirt_selected"]');
    var khaki = document.querySelector('input[name="khaki_hat_selected"]');
    var black = document.querySelector('input[name="black_hat_selected"]');
    var gray = document.querySelector('input[name="gray_hat_selected"]');

    if (shirt && shirt.checked) {
      html +=
        '<section class="static-selected-item"><h3>Shirt details</h3><div class="static-shirt-fields">' +
        '<label>Shirt size<select name="shirt_size" required><option value="">Select size</option><option>Small</option><option>Medium</option><option>Large</option><option>XL</option><option>2XL</option><option>3XL</option></select></label>' +
        '<label>Quantity<input type="number" name="shirt_quantity" min="1" value="1" required></label>' +
        "</div></section>";
    }
    if (khaki && khaki.checked) html += quantityBlock("Khaki hat", "khaki_hat_quantity");
    if (black && black.checked) html += quantityBlock("Black hat", "black_hat_quantity");
    if (gray && gray.checked) html += quantityBlock("Gray hat", "gray_hat_quantity");

    dynamicFields.innerHTML = html;
    formError.hidden = true;
  }

  itemInputs.forEach(function (input) {
    input.addEventListener("change", renderSelections);
  });

  shopForm.addEventListener("submit", function (event) {
    if (!itemInputs.some(function (input) { return input.checked; })) {
      event.preventDefault();
      formError.textContent = "Please choose at least one shirt or hat before sending your request.";
      formError.hidden = false;
      picker.scrollIntoView({ behavior: "smooth", block: "center" });
    }
  });
})();
