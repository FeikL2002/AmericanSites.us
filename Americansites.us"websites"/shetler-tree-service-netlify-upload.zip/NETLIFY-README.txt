SHETLER TREE SERVICE — NETLIFY UPLOAD

This package contains one responsive website for both desktop and mobile.

QUICK UPLOAD
1. Sign in at https://app.netlify.com/drop
2. Drag this ZIP file onto the upload area.
3. Netlify will publish the site and provide a temporary URL.

Included pages:
- Home
- Our Work
- Merch
- Contact

The contact and merch forms submit directly from the website.
The AmericanSites.us developer credit links to https://www.americansites.us/.

FORM DELIVERY
Both the main contact form and the merch inquiry form send submissions to
Shetlertree@gmail.com through FormSubmit. The first submission triggers a
one-time activation email. Open that message in the Gmail inbox and confirm
the form; every later submission will then be delivered automatically.
